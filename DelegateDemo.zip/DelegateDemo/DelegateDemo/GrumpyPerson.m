//
//  GrumpyPerson.m
//  DelegateDemo
//
//  Created by Derrick Park on 2018-09-13.
//  Copyright © 2018 Derrick Park. All rights reserved.
//

#import "GrumpyPerson.h"

@implementation GrumpyPerson

- (BOOL)shouldSayHello {
	return NO;
}

@end
