//
//  LovelyPerson.m
//  DelegateDemo
//
//  Created by Derrick Park on 2018-09-13.
//  Copyright © 2018 Derrick Park. All rights reserved.
//

#import "LovelyPerson.h"

@implementation LovelyPerson

- (BOOL)shouldSayHello {
	return YES;
}

@end
